#include <iostream>
using namespace std;

float cambiaSigno(float num)
{
	float a = -num;
	return a;
}
void pon13(int i)
{
	//Si en el par�metro no pongo int& i , el valor del parametro no cambia
	i = 13;
}
void fillVector(int v[],int vLong)
{
	for (int i = 0; i < vLong; i++){
		v[i] = i;
	}
}



int main()
{
	int v[4];
	int c;
	cout << "Hola mundo" << endl;
	cout << "14 pasa a: " << cambiaSigno(14) << endl;
	cout << "Introduce c:";
	cin >> c; //Lee por pantalla y lo almacena en c
	pon13(c);
	cout << "c es: " << c << endl;
	fillVector(v, 4);
	for (int i = 0; i < 4; i++){
		cout << v[i];
	}
	cout << endl;

	const unsigned int maxCad = 100; //const sirve para definir constantes
	char cad[maxCad];
	cin.getline(cad, maxCad); //lee hasta 99 caracteres de la consola cuando se pulse enter, deja en la cadena los caracteres leidos y a�ade un terminador

	return 0;

}