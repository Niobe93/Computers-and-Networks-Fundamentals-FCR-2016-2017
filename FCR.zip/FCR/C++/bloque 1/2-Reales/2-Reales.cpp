#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	//float f;
	//f = -27.625;
	//cout << "f es:" << f << endl;

	float f1 = 0.1;
	float f2 = 0.3;
	cout << "f1: " << setprecision(15) << f1 << endl;
	cout << "f2: " << setprecision(15) << f2 << endl;

	const float TOLERANCIA = 0.0000001;
	if (fabs(f1*3.0 - f2) < TOLERANCIA){
		cout << "Son iguales" << endl;
	}
	else{
		cout << "Son distintos" << endl;
	}





	return 0;
}
