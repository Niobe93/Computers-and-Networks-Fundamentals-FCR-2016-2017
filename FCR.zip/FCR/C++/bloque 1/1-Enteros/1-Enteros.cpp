#include <iostream>
using namespace std;


int media(int x, int y)
{
	int m;
	m = (x/2)+(y/2);
	return m;
}

int main()
{
	int  unsigned a;
	int b;
	int d;

	const int UN_MILLON = 1000000;
	int contador = 0;

	for (int i = 0; i < 3000 * UN_MILLON; i++)
		contador++;

	cout << "contador " << contador << endl;

	cin >> a;
	cin >> b;
	int resul;

	resul = a + b;
	cout << resul << endl;


	if (a>0 && b>0 && resul < 0)
	{
		cout << "Desbordamiento" << endl;
	}
	else if (a<0 && b<0 && resul > 0)
	{
		cout << "Desbordamiento" << endl;
	}

	d = media(a, b);
	cout << "La media es: " << d << endl;

	return 0;
}
