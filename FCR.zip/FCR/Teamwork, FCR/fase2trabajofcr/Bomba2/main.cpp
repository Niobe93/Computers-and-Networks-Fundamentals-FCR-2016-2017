#include "stages.h"

#include <iostream>

using std::cout;
using std::cin;
using std::endl;

int main()
{

	Stage3();

	cout << "Stage 3 disabled" << endl;

	Stage2();

	cout << "Stage 2 disabled" << endl;

	Stage1();

	cout << "Stage 1 disabled" << endl;

	Stage4();

	cout << "Stage 4 disabled" << endl;

	cout << "Wow, you've just saved the Earth!" << endl;
	return 1;
}