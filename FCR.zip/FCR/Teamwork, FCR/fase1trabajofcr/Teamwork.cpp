
#include <iostream>
#include <string>
using namespace std;


extern "C" bool IsValidAssembly(signed int a, int b);

const string ID = "238096";


//Debe imprimir un mensaje diciendo que la licencia es inv�lida
void InvalidLicense()
{
	cout << "Licencia Invalida" << endl;
	// salir llamando a la funci�n
	exit(EXIT_SUCCESS);
	
}


//Debe pedir una cadena y comprobar que coincide con ID. En caso contrario, se debe llamar a InvalidLicense().
void CheckPassword(string id2) 
{

	if (ID != id2)
		InvalidLicense();

}

//Debe pedir dos n�meros enteros de 32 bits.
void CheckBits(signed int v, signed int n) 
{
	// Debe llamar a InvalidLicense() en cualquiera de estos casos:	//El bit dos del primer numero NO es 1
	if ((v & 0x00000004) == 0)
		InvalidLicense();
	//El bit dos del primer numero no es igual al 3 bit del segundo numero
	int v2 = v >> 2;
	int n2 = n >> 3;
	v2 = v2 & 1;
	n2 = n2 & 1;
	if (n2!=v2)
		InvalidLicense();
	//Si al formar un entero de 32 bits tomando los 8 bits m�s significativos del primer n�mero con el
	//resto de bits del segundo n�mero, el resultado es menor de 0
	int v3 = ((v )& (0xFF000000));
	int b = ((n) & (0x00FFFFFF));
	int x = v3 | b;
	  if (x < 0)
		  InvalidLicense();

}
//Debe pedir un n�mero entero de 32 bits y pas�rselo como primer par�metro a la funci�n IsValidAssembly(). Como segundo par�metro se pasa 2.
void CheckAssembly( signed int y) {
	
	if (IsValidAssembly(y, 2) == 0)
		   InvalidLicense();
}
//Debe pedir un n�mero entero de 32 bits y comprobar, utilizando ensamblador en l�nea, que sus bits 2 y 3 son iguales
void CheckInlineAssembly(signed int b) {
	
	__asm {
		
		mov ebx, b; numero que pasamos como parametro
		mov ecx, 0x0000000C; mascara
		
		and ebx, ecx; relizamos la operacion and entre el numero y la copia de la mascara

		cmp ebx, ecx; comparamos la mascara con el resultado de la operacion anterior
		jz fin; si son iguales significa que los bits 2 y 3 eran 1, salta a fin
		cmp ebx, 0; si no eran iguales, puede que sean 0 y por tanto iguales
		jz fin; si son iguales salta al fin
		call InvalidLicense;si en los casos anteriores no son iguales llamamos a InvalidLicense
		fin :		
	
		}
	
}

int main()
{
	string cad;
	cout << "Introduzca un numero de licencia" << endl;
	cin >> cad;
	CheckPassword(cad);
	int x;
	int z;
	cout << "Introduzca un numero" << endl;
	cin >> x;
	cout << "Introduzca otro numero" << endl;
	cin >> z;
	CheckBits(x, z);	//4,8
	int y;
	cout << "Introduzca un numero" << endl;
	cin >> y;
	CheckAssembly(y); //2
	int w;
	cout << "Introduzca un numero" << endl;
	cin >> w;
	CheckInlineAssembly(w); //2
	cout << "Su licencia valida" << endl;

	return 0;
	
}


